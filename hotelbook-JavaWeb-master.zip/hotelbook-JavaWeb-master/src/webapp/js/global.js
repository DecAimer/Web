//服务器端url
var baseUrl = "http://localhost:8080/hb";

//不受这个影响的地址有：
//1. win10.js 854行 857行
//2. romeTypeTable.js 88行
//3. CommonFilter.java 54行